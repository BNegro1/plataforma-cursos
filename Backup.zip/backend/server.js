import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;

// Tipos MIME para archivos estáticos
const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.json': 'application/json',
};

const server = http.createServer((req, res) => {
  // Manejo de rutas API
  if (req.url.startsWith('/api')) {
    handleApiRequest(req, res);
    return;
  }

  // Servir archivos estáticos
  let filePath = path.join(__dirname, '..', 'public', req.url === '/' ? 'home.html' : req.url);
  
  // Verificar si el archivo existe
  fs.access(filePath, fs.constants.F_OK, (err) => {
    if (err) {
      res.writeHead(404);
      res.end('Archivo no encontrado');
      return;
    }

    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'text/plain' });
    fs.createReadStream(filePath).pipe(res);
  });
});

function handleApiRequest(req, res) {
  res.setHeader('Content-Type', 'application/json');
  
  switch(req.url) {
    case '/api/cursos':
      fs.readFile(path.join(__dirname, '..', 'data', 'cursos.json'), 'utf8', (err, data) => {
        if (err) {
          res.writeHead(500);
          res.end(JSON.stringify({ error: 'Error interno del servidor' }));
          return;
        }
        res.writeHead(200);
        res.end(data);
      });
      break;
    default:
      res.writeHead(404);
      res.end(JSON.stringify({ error: 'Ruta no encontrada' }));
  }
}

server.listen(PORT, () => {
  console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
});