
class AlternativaView {
    static renderAlternativas(alternativas) {
        const container = document.getElementById('alternativas-container');
        container.innerHTML = '';
        alternativas.forEach(alternativa => {
            const div = document.createElement('div');
            div.textContent = alternativa.text;
            container.appendChild(div);
        });
    }
}
