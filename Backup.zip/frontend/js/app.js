// Controlador principal del frontend
class AppController {
  constructor() {
    this.cursosModel = new CursosModel();
    this.cursosView = new CursosView();
    this.init();
  }

  async init() {
    this.setupEventListeners();
    await this.cargarCursos();
  }

  setupEventListeners() {
    document.getElementById('cursosBtn').addEventListener('click', () => this.mostrarSeccion('cursos'));
    document.getElementById('dashboardBtn').addEventListener('click', () => this.mostrarSeccion('dashboard'));
  }

  async cargarCursos() {
    try {
      const cursos = await this.cursosModel.obtenerCursos();
      this.cursosView.renderizarCursos(cursos);
    } catch (error) {
      console.error('Error al cargar cursos:', error);
    }
  }

  mostrarSeccion(seccionId) {
    document.querySelectorAll('.seccion').forEach(seccion => {
      seccion.classList.add('oculto');
    });
    document.getElementById(seccionId).classList.remove('oculto');
  }
}

// Modelo de Cursos
class CursosModel {
  async obtenerCursos() {
    try {
      const response = await fetch('/api/cursos');
      if (!response.ok) throw new Error('Error al obtener cursos');
      return await response.json();
    } catch (error) {
      throw new Error('Error en la petición: ' + error.message);
    }
  }
}

// Vista de Cursos
class CursosView {
  renderizarCursos(cursos) {
    const contenedor = document.getElementById('listaCursos');
    contenedor.innerHTML = cursos.map(curso => this.crearTarjetaCurso(curso)).join('');
  }

  crearTarjetaCurso(curso) {
    return `
      <div class="curso-card" data-id="${curso.id}">
        <h3>${curso.titulo}</h3>
        <p>${curso.descripcion}</p>
        <button onclick="app.inscribirEnCurso(${curso.id})">
          Inscribirse
        </button>
      </div>
    `;
  }
}

// Inicializar la aplicación
const app = new AppController();